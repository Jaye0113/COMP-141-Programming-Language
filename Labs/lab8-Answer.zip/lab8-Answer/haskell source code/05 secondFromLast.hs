secondFromLast :: [a] -> a
secondFromLast xs = xs !! (length xs - 2)
