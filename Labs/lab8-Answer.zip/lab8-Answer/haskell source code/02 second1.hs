second1 :: [a] -> a
second1 xs = head (tail xs)
