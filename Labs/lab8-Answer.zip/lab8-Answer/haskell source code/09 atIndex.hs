atIndex :: Int -> [a] -> a
atIndex n xs = last (take n xs)
