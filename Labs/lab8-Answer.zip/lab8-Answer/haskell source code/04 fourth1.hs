fourth1 :: [a] -> a
fourth1 xs = head (tail (tail (tail xs)))
