fourth :: [a] -> a
fourth xs = xs !! 3

