secondHalf :: [a] -> [a]
secondHalf xs = drop (length xs 'div' 2) xs

