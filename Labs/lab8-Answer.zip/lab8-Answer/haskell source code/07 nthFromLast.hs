nthFromLast :: Int -> [a] -> a
nthFromLast n xs = xs !! (length xs - n)
