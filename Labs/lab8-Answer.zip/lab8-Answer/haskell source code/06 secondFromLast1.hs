secondFromLast1 :: [a] -> a
secondFromLast1 xs = last (init xs)

