second :: [a] -> a
second xs = xs !! 1
