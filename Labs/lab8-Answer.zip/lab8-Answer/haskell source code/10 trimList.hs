trimList :: [a] -> [a]
trimList xs = take (length (drop 1 xs) - 1) (drop 1 xs)

