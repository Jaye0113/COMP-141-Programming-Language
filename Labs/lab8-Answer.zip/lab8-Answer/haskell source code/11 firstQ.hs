firstQ :: [a] -> [a]
firstQ xs = take (length xs `div` 4) xs

