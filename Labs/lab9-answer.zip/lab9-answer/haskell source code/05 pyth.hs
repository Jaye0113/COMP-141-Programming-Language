-- Define function pyth that receives a list triples of numbers and filters the ones that satisfy the Pythagorean theorem.
pyth :: [(Int, Int, Int)] -> [(Int, Int, Int)]
pyth triples = [(a, b, c) | (a, b, c) <- triples, a^2 == b^2 + c^2]


