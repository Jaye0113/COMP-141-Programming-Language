-- Define function divisors that receives a number and returns a list of all divisors of that number.
divisors :: Int -> [Int]
divisors n = [x | x <- [1..n], n `mod` x == 0]

-- Define function commonDiv that receives two numbers as input, and returns the list of all common divisors of those two input numbers.
commonDiv :: Int -> Int -> [Int]
commonDiv a b = let divA = divisors a
                    divB = divisors b
                in filter (`elem` divB) divA

-- Define function greatestCommonDiv that receives two numbers as input and returns the common divisor of those two input numbers.
greatestCommonDiv :: Int -> Int -> Int
greatestCommonDiv a b = maximum (commonDiv a b)

