-- Define function cartesian3 that receives three lists as input and creates the cartesian product list of them.
cartesian3 :: [a] -> [b] -> [c] -> [(a, b, c)]
cartesian3 list1 list2 list3 = [(a, b, c) | a <- list1, b <- list2, c <- list3]

