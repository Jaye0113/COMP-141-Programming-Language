-- Define function sumProduct that receives a list of numbers and returns a pair,where the first component is the summation of list elements, and the second component is the multiplication of list elements.
sumProduct :: [Int] -> (Int, Int)
sumProduct lst = (sum lst, product lst)
