-- Define function american that filters out Americans who are 20 years or younger.
american :: [(String, Int, String)] -> [String]
american ppl = [name | (name, age, country) <- ppl, country == "usa", age <= 20]

