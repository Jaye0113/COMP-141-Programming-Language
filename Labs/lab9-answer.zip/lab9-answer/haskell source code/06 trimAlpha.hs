-- Use list comprehensions to define function trimAlpha that receives a string and returns a new string containing only non-alphabetic characters.
trimAlpha :: String -> String
trimAlpha s = [c | c <- s, not (elem c ['a'..'z'] || elem c ['A'..'Z'])]

