-- Define function divisors that receives a number and returns a list of all divisors of that number.
divisors :: Int -> [Int]
divisors n = [x | x <- [1..n], n `mod` x == 0]


