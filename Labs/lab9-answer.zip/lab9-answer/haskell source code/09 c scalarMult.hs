-- Define a function to multiply a 3D vector by a scalar
scalarMult :: Int -> (Int, Int, Int) -> (Int, Int, Int)
scalarMult scalar (x, y, z) = (scalar * x, scalar * y, scalar * z)

